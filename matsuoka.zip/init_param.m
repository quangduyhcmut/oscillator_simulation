clc;
clear all;

%% Parameter for neuron2
% s1  = 1.0;
% q1  = 1;
% Tr1 = 0.03;
% Ta1 = 0.4;
% b1  = 2.5;
% w12 = 1.5;
% 
%% Parameter for neuron2
% s2  = 1.0;
% q2  = 1;
% Tr2 = 0.03;
% Ta2 = 0.4;
% b2  = 2.5;
% w21 = 1.5;

%% Parameter for neuron1
s1  = 5.0;
q1  = 1;
Tr1 = 1/32;
Ta1 = 1/2;
b1  = 2.0;
w12 = 2.0;

%% Parameter for neuron2
s2  = 5.0;
q2  = 1;
Tr2 = 1/32;
Ta2 = 1/2;
b2  = 2.0;
w21 = 2.0;