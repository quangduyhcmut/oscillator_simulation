Please refer to these papers:

Xu, W.; Fang, F. C.; Bronlund, J. & Potgieter, J. Generation of rhythmic and voluntary patterns of mastication using Matsuoka oscillator for a humanoid chewing robot Mechatronics, 2009, 19, 205 - 217
Liu, G.; Habib, M.; Watanabe, K. & Izumi, K. Central pattern generators based on Matsuoka oscillators for the locomotion of biped robots Artificial Life and Robotics, Springer Japan, 2008, 12, 264-269